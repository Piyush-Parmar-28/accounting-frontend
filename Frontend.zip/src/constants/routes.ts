const AgencyClients: string = "/organisations";

let routes = {
  AgencyClients,
};

export default routes;
