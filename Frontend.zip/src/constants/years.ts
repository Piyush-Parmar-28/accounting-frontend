const years = [{ name: "2022-23" }, { name: "2021-22" }];

export default years;
