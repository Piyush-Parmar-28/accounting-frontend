export const tabNames: any = {
  "2B Purchase": "2bCount",
  "2A Purchase": "2aCount",
  "No 2A/2B Purchase": "normalCount",
  "2B Return": "2bReturnCount",
  "2A Return": "2aReturnCount",
  "No 2A/2B Return": "normalReturnCount"
};
